import { Report } from './report';

describe('Report', () => {
  it('should create an instance', () => {
    expect(new Report()).toBeTruthy();
  });
});
