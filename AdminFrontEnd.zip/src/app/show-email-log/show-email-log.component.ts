import { Component, OnInit } from '@angular/core';
import { Email } from '../email';
import { AdminServiceService } from '../admin-service.service';

@Component({
  selector: 'app-show-email-log',
  templateUrl: './show-email-log.component.html',
  styleUrls: ['./show-email-log.component.css']
})
export class ShowEmailLogComponent implements OnInit {
email:Email[];
  constructor( private httpClientService:AdminServiceService) { }
 
 ngOnInit() {
 this.httpClientService.showEmailLog().subscribe(
 data =>{this.email = data;}
 )
 }
}
