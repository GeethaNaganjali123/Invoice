import { Component, OnInit } from '@angular/core';
import { CategoryReport } from '../category-report';
import { AdminServiceService } from '../admin-service.service';


@Component({
  selector: 'app-categoryreport',
  templateUrl: './categoryreport.component.html',
  styleUrls: ['./categoryreport.component.css']
})
export class CategoryreportComponent implements OnInit {

  productCategory: String;
  units: number;
  report = new CategoryReport();

  constructor(private businessService: AdminServiceService) { }

  ngOnInit() {
    this.businessService.getCategoryReport().subscribe((report) => {
      this.report = (report);
      console.log(report);
      console.log(this.report);
    }
    )
  }

}
