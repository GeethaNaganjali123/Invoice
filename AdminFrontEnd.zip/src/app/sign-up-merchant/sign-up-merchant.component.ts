import { Component, OnInit } from '@angular/core';
import { Merchant } from '../Merchant';
import { AdminpageComponent } from '../adminpage/adminpage.component';
import { AdminServiceService } from '../admin-service.service';
import { ThirdParty } from '../third-party';

@Component({
  selector: 'app-sign-up-merchant',
  templateUrl: './sign-up-merchant.component.html',
  styleUrls: ['./sign-up-merchant.component.css']
})
export class SignUpMerchantComponent implements OnInit {
  merchant: Merchant;
  tpmerchant: ThirdParty;
  constructor(private adminService: AdminServiceService) { }
  message: String;
  ngOnInit() {
  }
  // addMerchant(fname, lname, email, pan, password, address, phone) {


  //   this.merchant = new Merchant();
  //   this.merchant.address = address;
  //   this.merchant.emailId = email;
  //   this.merchant.panCard = pan;
  //   this.merchant.firstName = fname;
  //   this.merchant.lastName = lname;
  //   this.merchant.phoneNo = phone;
  //   if (this.adminService.getFromAdminDD()) {
  //     this.merchant.isValid = "ACCEPTED";
  //     this.merchant.merType = "DD"
  //   }
  //   else if (this.adminService.getFromAdminTP()) {
  //     this.merchant.isValid = "ACCEPTED";
  //     this.merchant.merType = "TP"
  //     // this.adminService.addTPMerchant(this.tpmerchant, password).subscribe(merchant => {
  //     //   this.message = this.tpmerchant.emailId;
  //     // });
  //   }
  //   else {
  //     this.merchant.isValid = "PENDING";
  //     this.merchant.merType = "DD"
  //   }
  //   this.adminService.addMerchant(this.merchant, password).subscribe(merchant => {
  //     this.message = merchant.merId
  //   });
  // }

  addMerchant(fname, lname, email, pan, password, address, phone) {


    this.merchant = new Merchant();
    this.merchant.address = address;
    this.merchant.emailId = email;
    this.merchant.panCard = pan;
    this.merchant.firstName = fname;
    this.merchant.lastName = lname;
    this.merchant.phoneNo = phone;
    if (this.adminService.getFromAdminDD) {
      this.merchant.isValid = "ACCEPTED";
      this.merchant.merType = "DD"
    }
    else if (this.adminService.getFromAdminTP) {
      this.merchant.isValid = "ACCEPTED";
      this.merchant.merType = "TP"
    }
    else {
      this.merchant.isValid = "PENDING";
      this.merchant.merType = "DD"
    }
    console.log(this.merchant);
    this.adminService.addMerchant(this.merchant, password).subscribe();
  }
}
