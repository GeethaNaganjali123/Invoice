import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlacedProductsComponent } from './placed-products.component';

describe('PlacedProductsComponent', () => {
  let component: PlacedProductsComponent;
  let fixture: ComponentFixture<PlacedProductsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlacedProductsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlacedProductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
