export class Email{
    fromMailId:string;
    toMailId:string;
    mail:string;
   constructor(fromm:string, too:string,maildata:string){
       this.fromMailId=fromm;
       this.toMailId=too;
       this.mail=maildata;
 
   }
   
     } 
