import { Customer } from './Customer';
import { Product } from './Product';
import { Merchant } from './Merchant';

export class OrderedItem{
    ordId:string;
    customer:Customer;
    product:Product;
    merchant:Merchant;
    orderTime:string;
    ordPrice:number;
    shippingAddress:string;
    orderStatus:string;
    ordQty:number;

}