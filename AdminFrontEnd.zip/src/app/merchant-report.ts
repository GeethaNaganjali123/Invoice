export class MerchantReport {

    merchantName: String;
    units: number;

    constructor() {

    }

}
